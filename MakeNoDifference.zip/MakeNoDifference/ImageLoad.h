#pragma once
#include <Windows.h>
#include <atlImage.h>

void LoadPicture(HDC memdc, HINSTANCE g_hinst, int left, int top, int right, int bottom, int pNumber);