#include "login.h"

void LoginScreen(HDC memdc)
{

}

void UserDataSave(TCHAR name[1000], int number)
{

}